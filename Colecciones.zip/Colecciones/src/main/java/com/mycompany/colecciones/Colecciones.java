/*
 * 
 */

package com.mycompany.colecciones;
import java.util.Random; 
import java.util.Scanner;
/**
 *
 * @author 
     
 
    * Escribir un programa que sea capaz de crear un array de 1.000 elementos de números aleatorios 
    * y retorne la posición y valor del número más alto y más bajo.
 
 */
public class Colecciones {


    public static void main(String[] args) {
        
        int[] numeros = new int[5];
        Random numerosAleatorios = new Random(); 
        for (int i = 0; i < 5; i++) {
        numeros[i] = numerosAleatorios.nextInt(10);
        
        System.out.println(" Array : [" + numeros[i] + "]");
        }
        int n;
        int numeroMinimo= 9999, numeroMaximo =0; 
        for (int i = 0; i < 5; i++) {
        n = numeros[i];
            if (n > numeroMaximo) {
              numeroMaximo = n;
            }
                if ( numeroMinimo > n) {
                    numeroMinimo = n;
                    
                }
            }
        
        System.out.println("El número mínimo en el arreglo es: " + numeroMinimo);
        System.out.println("El número máximo en el arreglo es: " + numeroMaximo);
    }
}

